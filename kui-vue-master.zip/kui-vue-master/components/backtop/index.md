## API
| 属性     | 说明                          | 类型            | 默认值 |
|--------|-----------------------------|---------------|-----|
| height | 页面滚动高度达到该值时才显示 `BackTop` 组件 | String,Number | 400 |
| bottom | 组件距离底部的距离                   | String,Number | 40  |
| right  | 组件距离右部的距离                   | String,Number | 40  |
| click  | 点击按钮时触发                     | Function      | -   |