<cn>
#### 垂直
垂直的列表。
</cn>

```vue
<template>
  <Descriptions title="订单信息" layout="vertical">
    <DescriptionsItem label="订单编号">20202203302200</DescriptionsItem>
    <DescriptionsItem label="价格">￥ 199.99</DescriptionsItem>
    <DescriptionsItem label="姓名">王大锤</DescriptionsItem>
    <DescriptionsItem label="电话">13888888888</DescriptionsItem>
    <DescriptionsItem label="收货地址">
      湖北省武汉市洪山区 光谷 188号
    </DescriptionsItem>
  </Descriptions>
</template>
```