import Descriptions from './descriptions'
import DescriptionsItem from './descriptionsItem'
export { Descriptions, DescriptionsItem }