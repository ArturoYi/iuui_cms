<cn>
#### 垂直
通过设置 `vertical` 呈现垂直模式,此时不显示左右箭头
</cn>

```vue
<template>
  <div>
    <Carousel vertical>
      <CarouselItem>1</CarouselItem>
      <CarouselItem>2</CarouselItem>
      <CarouselItem>3</CarouselItem>
      <CarouselItem>4</CarouselItem>
    </Carousel>  
  </div>
</template>
```