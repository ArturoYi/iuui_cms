
<cn>
#### 基本用法
简单的展示。
</cn>

```vue
<template>
  <div>
    <Empty />
  </div>
</template>
```