
<cn>
#### 无描述
无描述展示。
</cn>

```vue
<template>
  <div>
    <Empty :description="null"/>
  </div>
</template>
```