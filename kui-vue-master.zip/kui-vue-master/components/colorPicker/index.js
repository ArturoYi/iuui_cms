import ColorPicker from './colorpicker.jsx'
export default ColorPicker