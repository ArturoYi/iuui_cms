<script>
import Info from './info'
import Base from './base'
import Types from './types'
import Icon from './icon'
import Close from './close'
import CN from '../index.md'
export default {
  render() {
    return (
      <div>
        <Info class="typo"/>
        <Base />
        <Types />
        <Icon />
        <Close />
        <CN class="typo"/>
      </div>
    )
  }
}
</script> 