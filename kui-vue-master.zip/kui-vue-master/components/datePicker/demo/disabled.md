<cn>
#### 禁用
选择框的不可用状态。通过 `disabled` 设置
</cn>

```vue
<template>
  <div>
    <DatePicker disabled value="2019-10-12"/>
    <br/>
    <DatePicker disabled size="small" value="2019-10"/>
    <br/>
    <DatePicker disabled mode="range"/>
  </div>
</template>
```