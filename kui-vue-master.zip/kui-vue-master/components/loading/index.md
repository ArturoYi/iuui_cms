### Loading API
| 属性    | 说明             | 类型              | 默认值 |
|---------|------------------|-------------------|--------|
| start   | 开始加载         | Function          | -      |
| finish  | 完成加载         | Function          | -      |
| error   | 加载错误         | Function          | -      |
| update  | 手动更新进度     | Function(percent) | -      |
| destroy | vue的$.destroy() | Function          | -      |