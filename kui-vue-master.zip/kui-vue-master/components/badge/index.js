import Badge from './badge.jsx'
export default Badge