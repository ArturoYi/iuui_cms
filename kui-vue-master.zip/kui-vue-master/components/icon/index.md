### API 
| 属性        | 说明                         | 类型          | 默认值 |
| ----------- | ---------------------------- | ------------- | ------ |
| type        | 图标类型。遵循图标的命名规范 | String        | -      |
| size        | 图标的大小，单位是 px        | String,Number | -      |
| color       | 图标的颜色                   | String        | -      |
| spin        | 是否有旋转动画               | Boolen        | false  |
| strokeWidth | 图标的线条粗细               | Number        | false  |