import Icon from './icon'

Icon.install = function (vue) {
  vue.component(Icon.name, Icon)
}

export default Icon