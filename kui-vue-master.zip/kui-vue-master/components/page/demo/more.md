<cn>
#### 更多
更多分页。
</cn>

```vue
<template>
  <div class="demo-page">
    <Page :current="10" :total="200"/>
  </div>
</template>
```