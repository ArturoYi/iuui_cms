<cn>
#### 基本用法
基础分页。
</cn>

```vue
<template>
  <div class="demo-page">
    <Page :current="1" :total="50"/>
  </div>
</template>
```