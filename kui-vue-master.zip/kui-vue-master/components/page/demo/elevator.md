<cn>
#### 跳转
快速跳转到某一页。
</cn>

```vue
<template>
  <div class="demo-page">
    <Page :current="10" :total="200" show-elevator/>
  </div>
</template>
```