import Poptip from './poptip.jsx'
export default Poptip