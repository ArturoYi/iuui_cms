### BreadcrumbItem API
| 属性        | 说明                                      | 类型      | 默认值   |
|-----------|-----------------------------------------|---------|-------|
| separator | 自定义分隔符                                  | String  | /     |
| to        | 自定义链接函数,和 `vue-router` 配合使用             | String  | -     |
| replace   | 路由跳转时，开启 `replace` 将不会向 `history` 添加新记录 | Boolean | false |
| icon      | 按钮的图标                                   | String  | -     |