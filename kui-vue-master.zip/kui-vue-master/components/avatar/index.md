## API
| 属性  | 说明                         | 类型                       | 默认值  |
| ----- | ---------------------------- | -------------------------- | ------- |
| icon  | 设置头像的图标类型           | String,Number              | 400     |
| shape | 指定头像的形状	circle,square | String                     | circle  |
| size  | 设置头像的大小               | large,small,default,Number | default |
| src   | 图片类头像的资源地址         | String                     | -       |