<script>
import Info from './info.md'
import Base from './base.md'
import Types from './types.md'
import Change from './change.md'
import CN from '../index.md'
export default {
  render() {
    return (
      <div>
        <Info class="typo" />
        <Base />
        <Types />
        <Change />
        <CN class="typo" />
      </div>
    )
  }
}
</script> 