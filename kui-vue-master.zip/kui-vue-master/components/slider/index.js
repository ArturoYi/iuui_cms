import Slider from './slider'
export default Slider