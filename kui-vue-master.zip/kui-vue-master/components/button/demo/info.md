# Button 按钮
按钮用于开始一个即时操作。

## 何时使用
标记了一个（或封装一组）操作命令，响应用户点击行为，触发相应的业务逻辑。

## 组件注册
```js
import { Button } from 'kui-vue';
Vue.use(Button);
```
## 代码演示