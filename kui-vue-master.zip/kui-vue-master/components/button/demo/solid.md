<cn>
#### 边框主题
只呈现边框
</cn>

```vue
<template>
  <div style="padding:10px;" class="demo-back">
    <Button type="primary" theme="solid">Primary</Button>
    <Button type="danger" theme="solid">Danger</Button>
    <Button type="warning" theme="solid">Warning</Button>
    <Button theme="solid">Default</Button>
    <Button type="dashed" theme="solid">Dashed</Button>
  </div>
</template>
```