import Divider from './divider.jsx'
export default Divider