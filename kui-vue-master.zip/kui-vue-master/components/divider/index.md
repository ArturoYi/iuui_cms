#### API
| 参数        | 说明                              | 类型                      | 默认值     |
|-------------|-----------------------------------|---------------------------|------------|
| text        | 分割线文字                        | String                    | -          |
| dashed      | 是否虚线                          | Boolean                   | false      |
| orientation | 分割线标题的位置 enum：left right | String                    | center     |
| type        | 水平还是垂直类型                  | enum: horizontal vertical | horizontal |
