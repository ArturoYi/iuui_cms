<cn>
#### 动画效果
显示动画效果。
</cn>

```vue
<template>
  <Skeleton animated />
</template>
```