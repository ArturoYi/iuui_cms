<cn>
#### 组合
可以配置骨架屏段落数量，以便更接近真实渲染效果。首行会被渲染一个长度 35% 的段首。
</cn>

```vue
<template>
  <Skeleton avatar  :rows="4"/>
</template>
```