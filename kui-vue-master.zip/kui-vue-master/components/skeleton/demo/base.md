<cn>
#### 基本用法
最简单的占位效果。
</cn>

```vue
<template>
  <Skeleton />
</template>
```