
<cn>
#### 加载大图
初步显示缩略图，点击查看大图。
>图片加载过程中会显示loading
</cn>

```vue
<template>
  <Image 
    :width="120" 
    src="https://www.chuchur.com/upload/demo/test_300.jpg"
    origin="https://www.chuchur.com/upload/demo/test.jpg"
    />
</template>
```