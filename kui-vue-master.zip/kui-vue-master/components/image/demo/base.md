
<cn>
#### 基本用法
简单的展示。
</cn>

```vue
<template>
  <Image 
    :width="120" 
    src="https://www.chuchur.com/upload/demo/test_300.jpg"
    />
</template>
```