import Affix from './affix.jsx'
export default Affix