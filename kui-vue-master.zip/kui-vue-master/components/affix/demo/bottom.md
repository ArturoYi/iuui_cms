<cn>
#### 基本 
最简单的用法。
</cn>

```vue
<template>
  <Affix :offsetBottom="10">
    <Button type="primary">10px to affix bottom</Button>
  </Affix>
  <br/>
  <Affix :offsetBottom="90">
    <Button type="primary">90px to affix bottom</Button>
  </Affix>
</template>
```