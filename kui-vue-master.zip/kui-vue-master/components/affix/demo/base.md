<cn>
#### 基本 
最简单的用法。
</cn>

```vue
<template>
  <Affix :offsetTop="100">
    <Button type="primary">Affix top</Button>
  </Affix>
  <br/>
</template>
```