export default {
  name: 'Link',
  props: {
    href: String,
    target: String,
    title: String,
  },
  render() {
    return <div></div>
  }
}