<cn>
#### 基本
最简单的用法。
</cn>

```vue
<template>
  <div>
   
  </div>
</template>
```