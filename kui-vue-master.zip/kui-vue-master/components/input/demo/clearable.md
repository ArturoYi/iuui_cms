<cn>
#### 可清除
通过设置 `clearable` 属性可控制是否显示清空按钮
</cn>

```vue
<template>
  <div style="width:512px;">
    <Input type="text" placeholder="请输入内容..." clearable />
  </div>
</template>
```