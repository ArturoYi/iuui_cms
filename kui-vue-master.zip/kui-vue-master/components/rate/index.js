import Rate from './rate'
export default Rate