<cn>
#### 半星 
支持选中半星。
</cn>

```vue
<template>
  <div>
    <Rate allowHalf :value="2.5" />
  </div>
</template>
```