<cn>
#### 尺寸
`large` 为大尺寸， `small` 为小尺寸
</cn>

```vue
<template>
  <div style="width:512px;">
    <InputNumber placeholder="Large Input" size="large" icon="logo-kui" clearable />
    <br/>
    <br/>
    <InputNumber placeholder="Base Input" icon="logo-kui" clearable />
    <br/>
    <br/>
    <InputNumber size="small" placeholder="Small Input" icon="logo-kui" clearable />
  </div>
</template>
```