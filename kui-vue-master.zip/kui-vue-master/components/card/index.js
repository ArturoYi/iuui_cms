import Card from './card.jsx'
export default Card