### API
| 属性     | 说明             | 类型         | 默认值 |
|----------|------------------|--------------|--------|
| title    | 卡片的标题       | String、slot | -      |
| icon     | 卡片标题的图标   | String       | -      |
| bordered | 卡片是否显示边框 | Boolean      | true   |
| extra    | 卡片标题扩展     | slot         | -      |