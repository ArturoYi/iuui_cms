<script>
import Info from './info.md'
import Base from './base.md'
import Icon from './icon.md'
import Close from './close.md'
import CN from '../index.md'
export default {
  render() {
    return (
      <div>
        <Info class="typo" />
        <Base />
        <Icon />
        <Close />
        <CN class="typo" />
      </div>
    )
  }
}

</script> 